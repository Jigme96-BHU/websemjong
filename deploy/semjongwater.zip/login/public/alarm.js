var color = ['transparent', 'green'];

var colors = ['transparent', 'red'];
var active =0;


setInterval(function(){

    document.getElementById("c").style.backgroundColor= colors[active]; 
    // document.getElementById("c").style.backgroundColor= color[active];
    document.getElementById("c1").style.backgroundColor= color[active];
    document.getElementById("c2").style.backgroundColor= color[active];
    document.getElementById("c3").style.backgroundColor= color[active];
    document.getElementById("c4").style.backgroundColor= color[active];
    document.getElementById("c5").style.backgroundColor= color[active];
    document.getElementById("c6").style.backgroundColor= color[active];
    document.getElementById("c7").style.backgroundColor= color[active];
    document.getElementById("c8").style.backgroundColor= color[active];
    document.getElementById("c9").style.backgroundColor= color[active];
    active++;
    if(active == color.length) active =0;
}, 500);


